# Screen Recording Script (<= 5 minutes)

## Goal
Demonstrate the complete workflow **from code change → CI → container image → deployment → prediction**.

---

## 0) Setup (5–10 sec)
**Show**
- Repo opened in terminal / VS Code
- `git status` clean

**Say**
- “This is my MLOps pipeline for Cats vs Dogs classification with DVC, MLflow, FastAPI, Docker, CI/CD and monitoring.”

---

## 1) Data Preprocess (20–30 sec)
**Command**
```bash
python -m src.preprocess --raw_dir data/raw --processed_dir data/processed
```

**Show**
- `data/processed/train|val|test` folders
- Mention resize to 224×224 and 80/10/10 split

---

## 2) Train + MLflow Tracking (30–40 sec)
**Command**
```bash
python -m src.train
mlflow ui --backend-store-uri ./mlruns
```

**Show**
- MLflow UI: experiment run, parameters, metrics, artifacts
- Model artifact saved to `models/model.pt`

---

## 3) Run Tests (10–15 sec)
**Command**
```bash
pytest -q
```

**Show**
- Tests pass

---

## 4) Build & Run Docker (30–40 sec)
**Command**
```bash
docker build -t catsdogs:latest .
docker run -p 8000:8000 catsdogs:latest
```

**Show**
- container running
- logs show model loaded

---

## 5) Health + Prediction (30–40 sec)
**Command**
```bash
curl http://localhost:8000/health
curl -X POST http://localhost:8000/predict -F "file=@sample.jpg"
```

**Show**
- response includes label + probabilities
- logs show request count + latency

---

## 6) CI/CD (GitHub Actions) (40–60 sec)
**Show (in browser)**
- GitHub Actions tab
- Latest workflow run: tests + docker build

**Optional**
- If Docker Hub secrets configured: show image pushed

---

## 7) Deployment (Docker Compose) (20–30 sec)
**Command**
```bash
docker compose up -d --build
IMAGE_PATH=sample.jpg ./scripts/smoke_test.sh
```

**Show**
- smoke test passed

---

## Closing (5–10 sec)
**Say**
- “This completes the MLOps workflow: data preprocessing, MLflow tracking, containerized inference, CI, deployment, and monitoring through logs and counters.”
