import os
from pathlib import Path
import time

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

import mlflow
import mlflow.pytorch

from src.model import SimpleCNN
from src.utils.metrics import classification_metrics, confusion

DEFAULT_DATA_DIR = "data/processed"
DEFAULT_MODEL_PATH = "models/model.pt"

def train(
    data_dir: str = DEFAULT_DATA_DIR,
    epochs: int = 3,
    batch_size: int = 32,
    lr: float = 1e-3,
    device: str = "cuda" if torch.cuda.is_available() else "cpu"
):
    data_dir = Path(data_dir)
    train_dir = data_dir / "train"
    val_dir = data_dir / "val"

    if not train_dir.exists() or not val_dir.exists():
        raise FileNotFoundError(
            f"Processed data not found. Expected {train_dir} and {val_dir}. "
            "Run preprocess first."
        )

    tfm_train = transforms.Compose([
        transforms.RandomHorizontalFlip(),
        transforms.RandomRotation(10),
        transforms.ToTensor(),
    ])
    tfm_eval = transforms.Compose([
        transforms.ToTensor(),
    ])

    train_ds = datasets.ImageFolder(str(train_dir), transform=tfm_train)
    val_ds = datasets.ImageFolder(str(val_dir), transform=tfm_eval)

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, num_workers=2)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False, num_workers=2)

    model = SimpleCNN(num_classes=2).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)

    mlflow.set_experiment("cats-vs-dogs-mlops")
    with mlflow.start_run():
        mlflow.log_params({"epochs": epochs, "batch_size": batch_size, "lr": lr, "device": device})

        best_val_acc = 0.0
        for epoch in range(1, epochs + 1):
            model.train()
            running_loss = 0.0
            t0 = time.time()
            for xb, yb in train_loader:
                xb, yb = xb.to(device), yb.to(device)
                optimizer.zero_grad()
                logits = model(xb)
                loss = criterion(logits, yb)
                loss.backward()
                optimizer.step()
                running_loss += loss.item() * xb.size(0)

            train_loss = running_loss / len(train_ds)

            # validation
            model.eval()
            y_true, y_pred = [], []
            val_loss_sum = 0.0
            with torch.no_grad():
                for xb, yb in val_loader:
                    xb, yb = xb.to(device), yb.to(device)
                    logits = model(xb)
                    loss = criterion(logits, yb)
                    val_loss_sum += loss.item() * xb.size(0)
                    preds = torch.argmax(logits, dim=1)
                    y_true.extend(yb.cpu().numpy().tolist())
                    y_pred.extend(preds.cpu().numpy().tolist())
            val_loss = val_loss_sum / len(val_ds)
            m = classification_metrics(y_true, y_pred)
            epoch_time = time.time() - t0

            mlflow.log_metrics({
                "train_loss": train_loss,
                "val_loss": val_loss,
                "val_accuracy": m["accuracy"],
                "val_precision": m["precision"],
                "val_recall": m["recall"],
                "val_f1": m["f1"],
                "epoch_time_sec": epoch_time
            }, step=epoch)

            if m["accuracy"] > best_val_acc:
                best_val_acc = m["accuracy"]
                Path("models").mkdir(exist_ok=True)
                torch.save(model.state_dict(), DEFAULT_MODEL_PATH)
                mlflow.log_artifact(DEFAULT_MODEL_PATH)

        # Save the model as an MLflow model too
        mlflow.pytorch.log_model(model, artifact_path="mlflow_model")

    print(f"Training complete. Best val accuracy={best_val_acc:.4f}. Model saved to {DEFAULT_MODEL_PATH}")

if __name__ == "__main__":
    train()
